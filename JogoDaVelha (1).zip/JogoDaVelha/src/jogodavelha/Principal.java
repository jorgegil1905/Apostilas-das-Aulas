package jogodavelha;

/**
 *
 * @author User
 */
public class Principal {
 
       public static void main(String args[]){
       JogoVelha app = new JogoVelha();
        app.startGame();
    }
}
