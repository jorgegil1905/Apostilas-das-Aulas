/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculamedia;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class FormMedia extends JFrame implements ActionListener{

    private  JButton btnMedia;
    private  JButton btnLimpar;
    private  JTextField  txtN1;
    private  JTextField  txtN2;
    private  JTextField  txtN3;
    private  JTextField  txtN4;
    private  JLabel      lblMedia;
    private  Container container;
   
    public FormMedia() {
       super("Calcula Media");
       this.setLayout(new FlowLayout());
       container = this.getContentPane();
       btnMedia  = new JButton("CALCULAR");
       btnLimpar = new JButton("LIMPAR");   
    
       txtN1 = new JTextField(12);   
       txtN2 = new JTextField(12);   
       txtN3 = new JTextField(12);   
       txtN4 = new JTextField(12);   
 
       lblMedia = new JLabel("0.0");
       
       container.add(new JLabel("Media : "));
       container.add(lblMedia);
       
       container.add(new JLabel("N1"));
       container.add(txtN1);
       
       container.add(new JLabel("N2"));
       container.add(txtN2);
       
       container.add(new JLabel("N3"));
       container.add(txtN3);
       
       container.add(new JLabel("N4"));
       container.add(txtN4);
    
       container.add(btnMedia);
       container.add(btnLimpar);
       
       btnMedia.addActionListener(this);
       btnLimpar.addActionListener(this);

       this.pack();
       this.setSize(1000, 300);
       this.setVisible(true); 
       
     
 }
    
    @Override
    public void actionPerformed(ActionEvent e){
     
       
       if(e.getSource() == btnMedia){
          this.validaCmpos(); 
          this.calculaMedia(); 
       }else{
          this.limparCampos();
       }        
    }
    
    private void calculaMedia(){
    
        double n1 = Double.parseDouble(txtN1.getText());
        double n2 = Double.parseDouble(txtN2.getText());
        double n3 = Double.parseDouble(txtN3.getText());
        double n4 = Double.parseDouble(txtN4.getText());
        
        double media = (n1 + n2+ n3 + n4) / 4;
        
        lblMedia.setText(String.valueOf(media));
        
    }
    private void limparCampos(){
        txtN1.setText("");             
        txtN2.setText("");             
        txtN3.setText("");             
        txtN4.setText("");            
        lblMedia.setText("0.00");
    }
    public boolean validaCmpos(){
        String n1 = txtN1.getText().trim();
        String n2 = txtN2.getText().trim();
        String n3 = txtN3.getText().trim();
        String n4 = txtN4.getText().trim();
        if (n1.equals("")){
        JOptionPane.showMessageDialog(this, "Valor 1 informado invalido", "Erro", JOptionPane.ERROR_MESSAGE );
        txtN1.requestFocus();
        return false;
        }
        
        if (n2.equals("")){
        JOptionPane.showMessageDialog(this, "Valor 2 informado invalido", "Erro", JOptionPane.ERROR_MESSAGE );
        txtN2.requestFocus();
        return false;
        }
        
        if (n3.equals("")){
        JOptionPane.showMessageDialog(this, "Valor 3 informado invalido", "Erro", JOptionPane.ERROR_MESSAGE );
        txtN3.requestFocus();
        return false;
        }
        
        if (n4.equals("")){
        JOptionPane.showMessageDialog(this, "Valor 4 informado invalido", "Erro", JOptionPane.ERROR_MESSAGE );
        txtN4.requestFocus();
        return false;
        }
        
        try {
             Double.parseDouble(n1);
        } catch(Exception e )  {
            JOptionPane.showMessageDialog(this, "Valor invalido", "Erro", JOptionPane.ERROR_MESSAGE );
            txtN1.setText("");
            txtN1.requestFocus();
            return false;
        }
        
        try {
            Double.parseDouble(n2);
        } catch(Exception e )  {
            JOptionPane.showMessageDialog(this, "Valor invalido", "Erro", JOptionPane.ERROR_MESSAGE );
            txtN2.setText("");
            txtN2.requestFocus();
            return false;
        }

        try {
            Double.parseDouble(n3);
        } catch(Exception e )  {
            JOptionPane.showMessageDialog(this, "Valor invalido", "Erro", JOptionPane.ERROR_MESSAGE );
            txtN3.setText("");
            txtN3.requestFocus();
            return false;
        }

        try {
            Double.parseDouble(n3);
        } catch(Exception e )  {
            JOptionPane.showMessageDialog(this, "Valor invalido", "Erro", JOptionPane.ERROR_MESSAGE );
            txtN3.setText("");
            txtN3.requestFocus();
            return false;
        }
        
        try {
            Double.parseDouble(n4);
        } catch(Exception e )  {
            JOptionPane.showMessageDialog(this, "Valor invalido", "Erro", JOptionPane.ERROR_MESSAGE );
            txtN4.setText("");
            txtN4.requestFocus();
            return false;
        }
        return false;
    
    }
}
    
