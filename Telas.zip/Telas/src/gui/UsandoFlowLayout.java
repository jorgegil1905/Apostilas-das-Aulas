/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;

public class UsandoFlowLayout {
    public static void main(String[] args) {
        Frame janela = new Frame();
        janela.setTitle( "Titulo da janela");
        
        janela.setLayout(new FlowLayout());
        
        Button btn1  = new Button("Botao 1");
        Button btn2  = new Button("Botao 2");
        Button btn3  = new Button("Botao 3");
        Button btn4  = new Button("Botao 4");
        Button btn5  = new Button("Botao 5");
        
        janela.add(btn1);
        janela.add(btn2);
        janela.add(btn3);
        janela.add(btn4);
        janela.add(btn5);
        
        janela.setSize(640, 480);
        janela.setVisible(true);
    } 
}
