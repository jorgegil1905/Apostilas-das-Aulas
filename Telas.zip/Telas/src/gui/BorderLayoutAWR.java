/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Frame;


public class BorderLayoutAWR {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Frame janela = new Frame();
        janela.setTitle( "Titulo da janela");
        Button btnNorte  = new Button("Botao Norte");
        Button btnSul    = new Button("Botao Sul");
        Button btnLeste  = new Button("Botao Leste");
        Button btnOeste  = new Button("Botao Oeste");
        Button btnCentro = new Button("Botao Centro");
        janela.add(btnNorte, BorderLayout.NORTH);
        janela.add(btnSul,   BorderLayout.SOUTH);
        janela.add(btnLeste, BorderLayout.EAST);
        janela.add(btnOeste, BorderLayout.WEST);
        janela.add(btnCentro, BorderLayout.CENTER);
        
        janela.setSize(640, 480);
        janela.setVisible(true);
    }
}
