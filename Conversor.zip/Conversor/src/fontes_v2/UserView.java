// Tratar GCLGEN
package fontes_v2;

import java.io.File;
import javax.swing.JOptionPane;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import javax.swing.JFileChooser;
import java.util.ArrayList;
import javax.swing.AbstractButton;
import java.awt.Color;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.JScrollPane;
import java.awt.Component;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionListener;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import java.awt.EventQueue;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JTextArea;
import javax.swing.JFrame;

public class UserView {
    private JFrame frmSqlRapido;
    private JTextArea textArea;
    private ButtonGroup buttonGroup;
    private JRadioButton rdbtnInsert;
    private JRadioButton rdbtnUpdate;
    private JRadioButton rdbtnSelect;
    private JRadioButton rdbtnCursor;
    private JRadioButton rdbtnDelete;
    private JCheckBox chckbxNulos;
    private JButton btnTratar;
    private JButton btnGerar;
    private JButton btnSelectAll;
    private JButton btnDeselectAll;
    private JList list;
    private JLabel jlcampoMsgErro;
    private JPanel panel_1;
    private JPanel panel_2;
    private int lastMsg;
    GeradorSQL gerador;
   
    public static void main(final String[] args) {
        EventQueue.invokeLater((Runnable)new UserView$1());
    }
      
    
    public UserView() {
        super();
        this.gerador = new GeradorSQL();
        this.initialize();
    }
    
    private void initialize() {
        (this.frmSqlRapido = new JFrame()).setTitle("Gerador de comandos COBOL atraves da DCLGEN");
        this.frmSqlRapido.setResizable(false);
        this.frmSqlRapido.setBounds(00, 00, 900, 720);
        this.frmSqlRapido.setDefaultCloseOperation(3);
        final JMenuBar menuBar = new JMenuBar();
        this.frmSqlRapido.setJMenuBar(menuBar);
        final JMenu mnArquivo = new JMenu("Arquivo");
        menuBar.add(mnArquivo);
        final JMenuItem mntmFechar = new JMenuItem("Fechar");
        mntmFechar.addActionListener((ActionListener)new UserView$2(this));
       
        final JMenuItem mntmAbrirArquivo = new JMenuItem("Abrir Arquivo...");
        mntmAbrirArquivo.addActionListener((ActionListener)new UserView$3(this));
        mnArquivo.add(mntmAbrirArquivo);
        mnArquivo.add(mntmFechar);
        final JMenu mnNewMenu = new JMenu("Ajuda");
        menuBar.add(mnNewMenu);
        final JMenuItem mntmAjuda = new JMenuItem("Ajuda");
        mntmAjuda.addActionListener((ActionListener)new UserView$4(this));
        mnNewMenu.add(mntmAjuda);
        final JMenuItem mntmSobre = new JMenuItem("Sobre o Conversor DCLGEN");
        mntmSobre.addActionListener((ActionListener)new UserView$5(this));
        mnNewMenu.add(mntmSobre);
        this.frmSqlRapido.getContentPane().setLayout(null);
        final JLabel label_1 = new JLabel("----+-*A-1-B--+----2----+----3----+----4----+----5----+----6----+----7--|-+----8");
        label_1.setFont(new Font("Courier", 0, 14));
        label_1.setBounds(13, 3, 675, 22);
        this.frmSqlRapido.getContentPane().add(label_1);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 25, 674, 600);
        this.frmSqlRapido.getContentPane().add(scrollPane);
        (this.textArea = new JTextArea()).setToolTipText("Clique em Arquivo, Abrir Arquivo e escolha uma DCLGEN.");
        scrollPane.setViewportView(this.textArea);
        this.buttonGroup = new ButtonGroup();
        (this.panel_1 = new JPanel()).setBorder(new TitledBorder(null, "Campo de Selecao", 4, 2, null, null));
        this.panel_1.setBounds(694, 182, 189, 402);
        this.frmSqlRapido.getContentPane().add(this.panel_1);
        this.panel_1.setLayout(null);
        (this.btnSelectAll = new JButton("Selecionar tudo")).setBounds(10, 21, 125, 25);
        this.panel_1.add(this.btnSelectAll);
        this.btnSelectAll.setEnabled(false);
        this.btnSelectAll.addActionListener((ActionListener)new UserView$6(this));
        (this.btnDeselectAll = new JButton("Desselecionar tudo")).setBounds(10, 53, 125, 25);
        this.panel_1.add(this.btnDeselectAll);
        this.btnDeselectAll.setEnabled(false);
        this.btnDeselectAll.addActionListener((ActionListener)new UserView$7(this));
        final JScrollPane scrollPane_1 = new JScrollPane();
        scrollPane_1.setBounds(10, 89, 169, 302);
        this.panel_1.add(scrollPane_1);
        scrollPane_1.setViewportView(this.list = new JList());
        (this.btnTratar = new JButton("Tratar DCLGEN")).addActionListener((ActionListener)new UserView$8(this));
        this.btnTratar.setBounds(704, 580, 169, 20);
        this.frmSqlRapido.getContentPane().add(this.btnTratar);
        (this.btnGerar = new JButton("Gerar")).setEnabled(false);
        this.btnGerar.addActionListener((ActionListener)new UserView$9(this));
        this.btnGerar.setBounds(704, 605, 169, 20);
        this.frmSqlRapido.getContentPane().add(this.btnGerar);
        (this.panel_2 = new JPanel()).setBorder(new TitledBorder(null, "", 4, 2, null, null));
        this.panel_2.setBounds(10, 631, 674, 24);
        this.frmSqlRapido.getContentPane().add(this.panel_2);
        this.panel_2.setLayout(null);
        (this.jlcampoMsgErro = new JLabel()).setBounds(0, 0, 674, 24);
        this.panel_2.add(this.jlcampoMsgErro);
        this.jlcampoMsgErro.setFont(new Font("Arial", 0, 6));
        this.jlcampoMsgErro.setForeground(Color.red);
        this.jlcampoMsgErro.setVisible(false);
        final JLabel lblByDanielsv = new JLabel("by danielsv");
        lblByDanielsv.setForeground(Color.LIGHT_GRAY);
        lblByDanielsv.setBounds(840, 658, 60, 14);
        lblByDanielsv.setVisible(false);
        this.frmSqlRapido.getContentPane().add(lblByDanielsv);
        final JPanel panel = new JPanel();
        panel.setBounds(695, 11, 189, 160);
        this.frmSqlRapido.getContentPane().add(panel);
        panel.setBorder(new TitledBorder(null, "Opcoes de formatacao", 4, 0, null, null));
        panel.setLayout(null);
        (this.rdbtnInsert = new JRadioButton("INSERT")).setBounds(17, 20, 73, 33);
        this.buttonGroup.add(this.rdbtnInsert);
        panel.add(this.rdbtnInsert);
        (this.rdbtnUpdate = new JRadioButton("UPDATE")).setBounds(17, 45, 83, 33);
        this.buttonGroup.add(this.rdbtnUpdate);
        panel.add(this.rdbtnUpdate);
        (this.rdbtnSelect = new JRadioButton("SELECT")).setBounds(17, 70, 73, 33);
        this.buttonGroup.add(this.rdbtnSelect);
        panel.add(this.rdbtnSelect);
        (this.rdbtnCursor = new JRadioButton("CURSOR")).setBounds(87, 70, 73, 35);
        this.buttonGroup.add(this.rdbtnCursor);
        panel.add(this.rdbtnCursor);
        (this.rdbtnDelete = new JRadioButton("DELETE")).setBounds(17, 95, 73, 33);
        this.buttonGroup.add(this.rdbtnDelete);
        panel.add(this.rdbtnDelete);
        (this.chckbxNulos = new JCheckBox("Nulidade")).setBounds(17, 122, 113, 33);
        this.chckbxNulos.setSelected(true);
        panel.add(this.chckbxNulos);
    }
    
    public void mensagemErro(final int x) {
 
        switch (x) {
            case 1: {
                this.jlcampoMsgErro.setText(" Nenhum padr�o de DCLGEN reconhecido!");
                break;
            }
            case 2: {
                if (this.lastMsg == 1) {
                    this.jlcampoMsgErro.setText(" Insira e HEHEHE trate novamente uma DCLGEN v�lida!");
                    break;
                }
                this.jlcampoMsgErro.setText(" Selecione ao menos um campo e um comando SQL e clique em Gerar!");
                break;
            }
            case 3: {
                if (this.lastMsg == 1) {
                    this.jlcampoMsgErro.setText(" Insira e trate novamente uma DCLGEN v�lida!");
                    break;
                }
                this.jlcampoMsgErro.setText(" SHeheheheheh");
                break;
            }            
            
        }
        this.lastMsg = x;
        this.jlcampoMsgErro.setVisible(true);
    }
    
    public void executarFormatacao(final int[] camposSelecionados) {
        ArrayList  saidaFormatada = null;
        int opcao = 0;
        
        if (this.rdbtnInsert.isSelected()) {
            opcao = 1;
        }
        else 
        	if (this.rdbtnSelect.isSelected()) {
            opcao = 2;
        }
        else if (this.rdbtnUpdate.isSelected()) {
            opcao = 3;
        }
        else if (this.rdbtnDelete.isSelected()) {
            opcao = 4;
        } 
        else if (this.rdbtnCursor.isSelected()) {
            opcao = 5;
        }
        else  {
        	 this.jlcampoMsgErro.setText(" � obrigatorio selecionar um dos comandos SQL");
        }
        if (opcao == 0)
        {
        	this.jlcampoMsgErro.setText(" � obrigatorio selecionar um dos comandos SQL");
            UserView.this.mensagemErro(2);
            
        }
        saidaFormatada = (ArrayList )this.gerador.formataSaida(opcao, camposSelecionados, this.chckbxNulos.isSelected());
        this.list.setListData(this.gerador.listaCamposMenu);
        String textoTratado = "";
        for (int i = 0; i < saidaFormatada.size(); ++i) {
            textoTratado = String.valueOf(textoTratado) + saidaFormatada.get(i) + "\n";
        }
        this.textArea.setText(textoTratado);
    }
    
    public void abrirArquivo() {
        final JFileChooser fileChosser = new JFileChooser();
        fileChosser.showOpenDialog(null);
        final File file = fileChosser.getSelectedFile();
        final StringBuffer sb = new StringBuffer();
        try {
            final FileReader fr = new FileReader(file);
            final BufferedReader br = new BufferedReader(fr);
            String linha;
            while ((linha = br.readLine()) != null) {
                sb.append(linha).append("\n");
            }
            this.textArea.setText(sb.toString());
           
        }
        catch (Exception e2) {
            JOptionPane.showMessageDialog(null, "Escolha um comando SQL, selecione os campos a serem tratados e clique em Gerar.");
        }
       
    }
    
    static /* synthetic */ JFrame access$0(final UserView userView) {
        return userView.frmSqlRapido;
    }
    
    static /* synthetic */ JButton access$1(final UserView userView) {
        return userView.btnTratar;
    }
    
    static /* synthetic */ JButton access$2(final UserView userView) {
        return userView.btnGerar;
    }
    
    static /* synthetic */ JButton access$3(final UserView userView) {
        return userView.btnSelectAll;
    }
    
    static /* synthetic */ JButton access$4(final UserView userView) {
        return userView.btnDeselectAll;
    }
    
    static /* synthetic */ JList access$5(final UserView userView) {
        return userView.list;
    }
    
    static /* synthetic */ JTextArea access$6(final UserView userView) {
        return userView.textArea;
    }
    
    static /* synthetic */ JLabel access$7(final UserView userView) {
        return userView.jlcampoMsgErro;
    }
}