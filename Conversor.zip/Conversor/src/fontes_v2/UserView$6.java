//Selecionar tudo
package fontes_v2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
class UserView$6 implements ActionListener {
    final /* synthetic */ UserView this$0;
    
    UserView$6(final UserView this$0) {
        super();
        this.this$0 = this$0;
 
    }
    
    public void actionPerformed(final ActionEvent e) {
        final int[] camposSelectedIndices = new int[this.this$0.gerador.listaCamposMenu.size()];
        for (int i = 0; i < camposSelectedIndices.length; ++i) {
            camposSelectedIndices[i] = i;
        }
        UserView.access$5(this.this$0).setSelectedIndices(camposSelectedIndices);
    }
}