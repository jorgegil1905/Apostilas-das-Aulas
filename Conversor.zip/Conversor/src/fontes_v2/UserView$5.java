// Sobre o Conversor DCLGEN
package fontes_v2;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView$5 implements ActionListener {
    final /* synthetic */ UserView this$0;
     
    UserView$5(final UserView this$0) {
        super();
        this.this$0 = this$0;
 
    }
    
    public void actionPerformed(final ActionEvent e) {
        final JanelaSobre jSobre = new JanelaSobre();
        jSobre.setLocationRelativeTo((Component)null);
        jSobre.setVisible(true);
    }
}