
package fontes_v2;
// Abrir arquivo
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView$3 implements ActionListener {
    final /* synthetic */ UserView this$0;
    
    UserView$3(final UserView this$0) {
    	   super();
        this.this$0 = this$0;
     
    }
    
    public void actionPerformed(final ActionEvent e) {
        this.this$0.abrirArquivo();
        UserView.access$1(this.this$0).setEnabled(true);
        UserView.access$2(this.this$0).setEnabled(false);
        UserView.access$3(this.this$0).setEnabled(false);
        UserView.access$4(this.this$0).setEnabled(false);
   
    }
}