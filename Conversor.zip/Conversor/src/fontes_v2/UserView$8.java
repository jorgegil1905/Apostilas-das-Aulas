// Tratar DCLGEN
package fontes_v2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

class UserView$8 implements ActionListener {
    final /* synthetic */ UserView this$0;
    
    UserView$8(final UserView this$0) {
    	  super();
         this.this$0 = this$0;
      
    }
    
    public void actionPerformed(final ActionEvent e) {
        final int ret = this.this$0.gerador.extrairDados(UserView.access$6(this.this$0).getText());
        if (ret > 0) {
            UserView.access$7(this.this$0).setVisible(false);
            this.this$0.executarFormatacao((int[])null);
            UserView.access$6(this.this$0).setToolTipText(null);
            UserView.access$2(this.this$0).setEnabled(true);
            UserView.access$3(this.this$0).setEnabled(true);
            UserView.access$4(this.this$0).setEnabled(true);
            JOptionPane.showMessageDialog(null, "Agora voc� deve escolher um comando SQL, selecionar os campos desejados e clicar no bot�o Gerar.");
        }
        else {
            this.this$0.mensagemErro(1);
        }
    }
}