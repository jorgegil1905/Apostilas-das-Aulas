// Botao GERAR 
package fontes_v2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView$9 implements ActionListener {
    final /* synthetic */ UserView this$0;
 
    UserView$9(final UserView this$0) {
        super(); 
        this.this$0 = this$0;
    
    }
    
    public void actionPerformed(final ActionEvent e) {
        UserView.access$5(this.this$0).getSelectedIndices();
        int[] camposSelectedIndices = new int[UserView.access$5(this.this$0).getSelectedIndices().length];
        camposSelectedIndices = UserView.access$5(this.this$0).getSelectedIndices();
        
       try {
        	
            UserView.access$7(this.this$0).setVisible(false);
            this.this$0.executarFormatacao(camposSelectedIndices);
        }
        catch (Exception e2) {
        	
        	 this.this$0.mensagemErro(2);
         
        }
       
        UserView.access$6(this.this$0).setToolTipText(null);
        UserView.access$7(this.this$0).setVisible(false);
        this.this$0.executarFormatacao(camposSelectedIndices);
    }
}