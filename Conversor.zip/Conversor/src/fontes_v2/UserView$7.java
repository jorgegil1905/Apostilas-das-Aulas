// Deselecionar tudo
package fontes_v2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView$7 implements ActionListener {
    final /* synthetic */ UserView this$0;
    
    UserView$7(final UserView this$0) {
        super();   
        this.this$0 = this$0;

    }
    
    public void actionPerformed(final ActionEvent e) {
        UserView.access$5(this.this$0).setSelectedIndices(null);
    }
}