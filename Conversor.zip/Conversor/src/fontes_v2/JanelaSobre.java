
package fontes_v2;

import java.awt.Component;
import javax.swing.JLabel;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.EventQueue;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class JanelaSobre extends JFrame {

    private JPanel contentPane; 
   
    public static void main(final String[] args) {
        EventQueue.invokeLater((Runnable)new JanelaSobre$1());
    }
    
    public JanelaSobre() {
        super();
        this.setTitle("Sobre o Conversor DCLGEN");
        this.setDefaultCloseOperation(1);
        this.setBounds(100, 100, 300, 160);
        (this.contentPane = new JPanel()).setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JLabel lblGeradorSql = new JLabel("Conversor DCLGEN");
        lblGeradorSql.setBounds(10, 11, 140, 14);
        this.contentPane.add(lblGeradorSql);
        final JLabel lblVerso = new JLabel("Versao: 1.0");
        lblVerso.setBounds(10, 46, 101, 14);
        this.contentPane.add(lblVerso);
        final JLabel lblDesenvolvidoEm = new JLabel("Liberado em: 29.08.2022");
        lblDesenvolvidoEm.setBounds(10, 64, 221, 14);
        this.contentPane.add(lblDesenvolvidoEm);
        final JLabel lblDesenvolvedorDanielDe = new JLabel("Desenvolvedor: Future Scholl");
        lblDesenvolvedorDanielDe.setBounds(10, 97, 206, 14);
        this.contentPane.add(lblDesenvolvedorDanielDe);
    }
}