// Arquivo
package fontes_v2;

import javax.swing.UIManager;

class UserView$1 implements Runnable {
    UserView$1() {
        super();
    }
     
    public void run() {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            final UserView window = new UserView();
            UserView.access$0(window).setVisible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}