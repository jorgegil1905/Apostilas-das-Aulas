
// Decompiled using: fernflower
// Took: 193ms

package fontes_v2;

import javax.swing.event.ListSelectionEvent;
import javax.swing.JList;
import javax.swing.event.ListSelectionListener;

class JanelaComoUtilizar$2 implements ListSelectionListener {
    final /* synthetic */ JanelaComoUtilizar this$0;
    private final /* synthetic */ JList val$list;
    
    JanelaComoUtilizar$2(final JanelaComoUtilizar this$0, final JList val$list) {
        super();
        this.this$0 = this$0;
        this.val$list = val$list;

    }
    
    public void valueChanged(final ListSelectionEvent arg0) {
        final int selecao = this.val$list.getSelectedIndex();
        String texto = null;
        switch (selecao) {
            case 0: {
                texto = "Este programa converte DCLGEN em se��es de c�digo COBOL\npara acesso a tabelas DB2.\n\nFormata tamb�m as vari�veis working para tratamento dos\ncampos nulos da tabela.\n\nAuxilia e acelera o desenvolvimento de programas.";
                JanelaComoUtilizar.access$0(this.this$0).setText(texto);
                 break;
            }
            case 1: {
                texto = "Para formatar seu c�digo cole a DCLGEN no campo de texto\nou insira abrindo seu arquivo.\n\nClicando em 'Tratar DCLGEN' o programa reconhecer� os campos\nda tabela e listar� ao lado.\n\nSelecione os campos da tabela e o formato SQL desejados e\nclique 'Gerar'. Automaticamente seu c�digo estar� formatado,\nbasta copiar colar.\n\nAs vari�veis working dos campos nulos s�o formatadas\nmantendo a op��o 'VARI�VEIS NULAS' selecionada.\n\n";
                JanelaComoUtilizar.access$0(this.this$0).setText(texto);
                break;
            }
            case 2: {
                texto = "Para comunicar falhas ou sugerir melhorias\nmande e-mail para daniel_vs@msn.com.";
                JanelaComoUtilizar.access$0(this.this$0).setText(texto);
                break;
            }
            default: {
                JanelaComoUtilizar.access$0(this.this$0).setText("Selecione o tema da d�vida");
                break;
            }
        }
    }
}