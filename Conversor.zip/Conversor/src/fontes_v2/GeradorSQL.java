package fontes_v2;

import java.util.Scanner;
import java.util.Vector;
import java.util.ArrayList;

public class GeradorSQL {
    private String nomeTabela;
    private String nomeLabel;
    private ArrayList listaCampos;
    private ArrayList listaVariaveisHost;
    private int start;
    private int end;
    private boolean primeiraLinha;
    private ArrayList textoRetorno;
    public Vector listaCamposMenu;
    
    public GeradorSQL() {
        super();
        this.listaCampos = null;
        this.listaVariaveisHost = null;
    }
    
    public int extrairDados(final String dclgen) {
        Scanner leitor = null;
        String linha = " ";
        int ret = 0;           
 
        
        try {
          
            for (leitor = new Scanner(dclgen), linha = leitor.nextLine(); !linha.contains("DCLGEN "); linha = leitor.nextLine()) {}
            while (leitor.hasNextLine() && !linha.contains("EXEC SQL")) {
                if (linha.contains("TABLE(")) {
                    this.extrairNomeTabela(linha);
                }
                if (linha.contains("LIBRARY(")) {
                    this.extrairNomeLabel(linha);
                }
                linha = leitor.nextLine();
            }
            this.listaCampos = new ArrayList();
            this.listaVariaveisHost = new ArrayList();
            this.primeiraLinha = true;
            this.listaCamposMenu = new Vector();
            while (!linha.contains("END-EXEC")) {
                linha = leitor.nextLine();
                this.processaLinha(linha);
            }
            ret = 1;
        }
        catch (Exception e) {
            System.out.println(e);
        }
        return ret;
    }
    
    public ArrayList formataSaida(final int opcao, final int[] camposSelecionados, final boolean formataAreaNulo) {
        String vCampo = null;
        String vNulo = null;
        String vHost = null;
        int xx = 0;
        int flag_null = 0;
        this.textoRetorno = new ArrayList();
        int[] camposSelecionadosAux;
        if (camposSelecionados == null) {
            camposSelecionadosAux = new int[this.listaCampos.size()];
            for (int i = 0; i < this.listaCampos.size(); ++i) {
                camposSelecionadosAux[i] = i;
            }
         
        }
     
        else {
            camposSelecionadosAux = new int[camposSelecionados.length];
            for (int i = 0; i < camposSelecionados.length; ++i) {
                camposSelecionadosAux[i] = camposSelecionados[i];
            }
        }
        if (opcao != 0) {
        this.formatacoesCobol(10);
        if (formataAreaNulo) {
            this.formatacoesCobol(1);
            for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                // vHost = (String) this.listaVariaveisHost.get( i );
                vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
               // vHost = (String) this.listaVariaveisHost.get( i , camposSelecionadosAux[i] , true);
                        // 	xx  = this.listaVariaveisHost.get( i ,xx[}, true );
            
                if (vHost.endsWith("-N")) {
                    flag_null =1 ;
                    for (vNulo = "WRK-" + vHost; vNulo.length() != 26; vNulo = vNulo.concat(" ")) {}
                    this.textoRetorno.add("          05 " + vNulo + "PIC S9(04) COMP VALUE ZEROS.");
                }
            }
        }
    
        }
        if (opcao != 0) {
      

            switch (opcao) {
                case 1: {
                	this.formatacoesCobol(12);
                	this.textoRetorno.add("           EXEC SQL");
                	this.textoRetorno.add("               INSERT INTO " + this.nomeTabela);
                    if (camposSelecionadosAux.length > 0) {
                        this.textoRetorno.add("                      (" + this.listaCampos.get(camposSelecionadosAux[0]));
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            this.textoRetorno.add("                      ," + this.listaCampos.get(camposSelecionadosAux[i]));
                        }                                                                 
                        this.textoRetorno.add("                      ," + this.listaCampos.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]) + ")");
                        vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                        this.textoRetorno.add("               VALUES (:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        if (vHost.endsWith("-N")) {
                               flag_null =1 ;
                            this.textoRetorno.add("                          :WRK-" + vHost);
                        }
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                      ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                            if (vHost.endsWith("-N")) {
                                this.textoRetorno.add("                          :WRK-" + vHost);
                            }
                        }
                        vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        this.textoRetorno.add("                      ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        if (vHost.endsWith("-N")) {
                            this.textoRetorno.add("                          :WRK-" + vHost);
                        }
                        final int ind = this.textoRetorno.size() - 1;
                        this.textoRetorno.set(ind, String.valueOf(this.textoRetorno.get(ind)) + ")");
                        break;
                    }
                    this.textoRetorno.add("                      (" + this.listaCampos.get(camposSelecionadosAux[0]) + ")");
                    vHost = (String)this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                    this.textoRetorno.add("               VALUES (:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                    if (vHost.endsWith("-N")) {
                        this.textoRetorno.add("                          :WRK-" + vHost);
                    }
                   
                }
            
                
                case 2: {
                	this.formatacoesCobol(12);
                	this.textoRetorno.add("           EXEC SQL");
                	this.textoRetorno.add("               SELECT " + this.listaCampos.get(camposSelecionadosAux[0]));
                    if (camposSelecionadosAux.length > 0) {
                        for (int i = 1; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      ," + this.listaCampos.get(camposSelecionadosAux[i]));
                        }
                    }
                    vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                    this.textoRetorno.add("                 INTO :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                    if (vHost.endsWith("-N")) {
                        this.textoRetorno.add("                           :WRK-" + vHost);
                    }
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                     ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                            if (vHost.endsWith("-N")) {
                                this.textoRetorno.add("                           :WRK-" + vHost);
                            }
                        }
                        vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        this.textoRetorno.add("                     ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        if (vHost.endsWith("-N")) {
                            this.textoRetorno.add("                           :WRK-" + vHost);
                        }
                    }
                    this.textoRetorno.add("                 FROM " + this.nomeTabela);
                    this.textoRetorno.add("                WHERE" );
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      " + this.listaCampos.get(camposSelecionadosAux[i]));
                            vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                               =  :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        }
                    }
                   
                    break;
                }
                case 3: {
                	this.formatacoesCobol(12);
                	this.textoRetorno.add("           EXEC SQL");
                	this.textoRetorno.add("               UPDATE " + this.nomeTabela);
                    vCampo = (String) this.listaCampos.get(camposSelecionadosAux[0]);
                    vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                    this.textoRetorno.add("                  SET " + vCampo + " = :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2) + ",");
                    if (camposSelecionadosAux.length > 0) {
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            vCampo = (String) this.listaCampos.get(camposSelecionadosAux[i]);
                            vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                      " + vCampo + " = :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2) + ",");
                        }
                        vCampo = (String) this.listaCampos.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        this.textoRetorno.add("                      " + vCampo + " = :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                    }
                    this.textoRetorno.add("                WHERE ");
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      " + this.listaCampos.get(camposSelecionadosAux[i]));
                            this.textoRetorno.add("                               =  :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        }
                    }
                      break;
                }
                case 4: {
                    this.formatacoesCobol(12);
                    this.textoRetorno.add("           EXEC SQL");
                	this.textoRetorno.add("               DELETE FROM " + this.nomeTabela);
                    if (camposSelecionadosAux.length > 0) {
                        vCampo = (String) this.listaCampos.get(camposSelecionadosAux[0]);
                        vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                        this.textoRetorno.add("                WHERE ");
                        this.textoRetorno.add("                      " + vCampo + " = ");
                            this.textoRetorno.add("                       :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2) + ",");
 
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            vCampo =  (String) this.listaCampos.get(camposSelecionadosAux[i]);
                            vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                  AND " + vCampo + " = ");
                            this.textoRetorno.add("                       :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2) + ",");
                        }
                        vCampo = (String) this.listaCampos.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                            this.textoRetorno.add("                  AND " + vCampo + " = ");
                            this.textoRetorno.add("                       :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                            break;
                    }
                    vCampo = (String) this.listaCampos.get(camposSelecionadosAux[0]);
                    vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                    this.textoRetorno.add("                WHERE " );
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      " + this.listaCampos.get(camposSelecionadosAux[i]));
                            this.textoRetorno.add("                               =  :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        }
                    }
                    this.textoRetorno.add("           END-EXEC");
                    this.formatacoesCobol(3);
                    break;
                }
                
                case 5: {
                 
                    this.formatacoesCobol(5);
                    this.textoRetorno.add("           EXEC SQL");
                    this.textoRetorno.add("               DECLARE CSR01-CURSOR CURSOR FOR  ");
                    this.textoRetorno.add("               SELECT " + this.listaCampos.get(camposSelecionadosAux[0]));
                    if (camposSelecionadosAux.length > 0) {
                        for (int i = 1; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      ," + this.listaCampos.get(camposSelecionadosAux[i]));
                        }
                    }
                    this.textoRetorno.add("                 FROM " + this.nomeTabela);
                    this.textoRetorno.add("                WHERE" );
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                            this.textoRetorno.add("                      " + this.listaCampos.get(camposSelecionadosAux[i]));
                            vHost =  (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                               =  :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        }
                    }
                    this.textoRetorno.add("           END-EXEC.");
                    
                    this.formatacoesCobol(2);
                    this.formatacoesCobol(6);
                    this.textoRetorno.add("           EXEC SQL");
                    this.textoRetorno.add("                FETCH CSR01-CURSOR ");
                    vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[0]);
                    this.textoRetorno.add("                INTO :" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                    if (vHost.endsWith("-N")) {
                        this.textoRetorno.add("                           :WRK-" + vHost);
                    }
                    if (camposSelecionadosAux.length > 1) {
                        for (int i = 1; i < camposSelecionadosAux.length - 1; ++i) {
                            vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
                            this.textoRetorno.add("                     ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                            if (vHost.endsWith("-N")) {
                                flag_null =1 ;
                                this.textoRetorno.add("                           :WRK-" + vHost);
                            }
                        }
                        vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[camposSelecionadosAux.length - 1]);
                        this.textoRetorno.add("                     ,:" + this.nomeLabel + "." + vHost.substring(0, vHost.length() - 2));
                        if (vHost.endsWith("-N")) {
                            this.textoRetorno.add("                           :WRK-" + vHost + " OF " + this.nomeLabel);
                        }
                    	                      
                    }
    
                    break;
                }
                
              
            }
        
            this.textoRetorno.add("           END-EXEC.");
            this.textoRetorno.add("      *");
            
            //this.textoRetorno.add("      *----------------------------------------------------------------*");
            //this.textoRetorno.add("       XXXX-99-FIM.                              EXIT.                        ");
            //this.textoRetorno.add("      *----------------------------------------------------------------*");
            //this.textoRetorno.add("      *");    
                 
            this.textoRetorno.add("           IF (SQLCODE                 NOT EQUAL ZEROS AND +100) OR ");     
            this.textoRetorno.add("              (SQLWARN0                EQUAL 'W')                       ");
            this.textoRetorno.add("              SET DB2-SELECT                TO TRUE                    ");
            this.textoRetorno.add("              MOVE '0120'                   TO FUTUW001-COD-ERRO       ");
            this.textoRetorno.add("                                            OF DFHCOMMAREA             ");
            this.textoRetorno.add("              MOVE '2222-ACESSAR-FUTUB010'  TO FUTU-S-IDEN-PARAGRAFO ");
            this.textoRetorno.add("              PERFORM 9100-ERRO-DB2                                    ");
            this.textoRetorno.add("           END-IF.                                                      ");
            this.textoRetorno.add("      *");

            if (flag_null == 1) {
                this.textoRetorno.add("          PERFOMR 2200-TRATAR-NULIDADE.");
            }             
            switch (opcao) {
            case 5: {
            	this.formatacoesCobol(8);
            	 this.formatacoesCobol(9);
            }
            }
       
        }
        if (opcao != 0) {
        if (formataAreaNulo) {
            this.formatacoesCobol(7);
            for (int i = 0; i < camposSelecionadosAux.length; ++i) {
                // vHost = (String) this.listaVariaveisHost.get( i );
                vHost = (String) this.listaVariaveisHost.get(camposSelecionadosAux[i]);
               // vHost = (String) this.listaVariaveisHost.get( i , camposSelecionadosAux[i] , true);
                        // 	xx  = this.listaVariaveisHost.get( i ,xx[}, true );
            
                if (vHost.endsWith("-N")) {
                    for (vNulo = "IF " + vHost; vNulo.length() != 26; vNulo = vNulo.concat(" ")) {}
                    this.textoRetorno.add("          ");
                    this.textoRetorno.add("          " + vNulo + "LESS ZEROS");
                    this.start = 1;
                    this.end = vHost.indexOf("-N", this.start);
                    vHost = vHost.substring(this.start, this.end);
                    this.textoRetorno.add("             MOVE ZEROS TO " + vHost + " OF "+ this.nomeLabel );
                    this.textoRetorno.add("          END-IF.");
                }
               
            }
            this.formatacoesCobol(8);
            this.formatacoesCobol(11);
            
        }
        }
        return this.textoRetorno;
    }
    
    public void extrairNomeTabela(final String linha) {
        this.start = linha.indexOf(".");
        this.end = linha.indexOf(")", this.start);
        this.nomeTabela = linha.substring(this.start, this.end);
    }
    
    public void extrairNomeLabel(final String linha) {
        this.start = linha.indexOf("))") - 10 ;
        this.end   = linha.indexOf("))");
        this.nomeLabel = linha.substring(this.start , this.end);
        int xx = this.nomeLabel.indexOf("(") +1 ;
        this.nomeLabel = this.nomeLabel.substring(xx , 10 );               
    }
    
    public void processaLinha(final String linha) {
        if (!linha.contains("END-EXEC")) {
            if (this.primeiraLinha) {
                this.start = linha.indexOf("( ");
            }
            this.primeiraLinha = false;
            this.end = linha.indexOf(" ", this.start + 2);
            final String nomeCampo = linha.substring(this.start + 2, this.end);
            this.listaCampos.add(nomeCampo);
            this.listaCamposMenu.add("- " + nomeCampo);
            String variavelHost = nomeCampo.replace('_', '-');
            if (!linha.contains("NULL")) {
                variavelHost = variavelHost.concat("-N");
            }
            else {
                variavelHost = variavelHost.concat("-0");
            }
            this.listaVariaveisHost.add(variavelHost);
        }
    }
    
    public void formatacoesCobol(final int opcao) {
        switch (opcao) {
            case 1: {
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       77  FILLER                      PIC X(050)      VALUE            ");
                this.textoRetorno.add("           '* AREA PARA VARIAVEIS DE NULIDADE *'.                       ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       01 WRK-AREA-NULOS.                                               ");
                break;
            }
            case 2: {
            	 this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("       PROCEDURE DIVISION.                        ");
                this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("      *");
                   
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0000-INICIO                      SECTION.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("            PERFORM  0100-PROCEDIMENTOS-INICIAIS."); 
                this.textoRetorno.add("            PERFORM  0200-PROCESSA.");
                this.textoRetorno.add("            PERFORM  9999-FINALIZA.");

                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0000-99-FIM.                     EXIT.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0100-PROCEDIMENTOS-INICIAIS     SECTION.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
                
                this.textoRetorno.add("            PERFORM  1900-FAZ-OPEN-CURSOR.");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0100-99-FIM.                     EXIT.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
               
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0200-PROCESSA                   SECTION.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
                
                this.textoRetorno.add("            PERFORM  2000-FAZ FECTH UNTIL CH-FIM = 'S'.");
                this.textoRetorno.add("            PERFORM  2100-FAZ-CLOSE-CURSOR.");
                 this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       0200-99-FIM.                     EXIT.                        ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
               
                //this.textoRetorno.add("      *----------------------------------------------------------------*");
                //this.textoRetorno.add("       XXXX-NOME-DA-SECAO              SECTION.                         ");
                //this.textoRetorno.add("      *----------------------------------------------------------------*");
                //this.textoRetorno.add("");
                
                //this.textoRetorno.add("           IF (SQLCODE                 NOT EQUAL ZEROS AND +100) OR ");     
                //this.textoRetorno.add("              (SQLWARN0                EQUAL 'W')                       ");
                //this.textoRetorno.add("              SET DB2-SELECT                TO TRUE                    ");
                //this.textoRetorno.add("              MOVE '0120'                   TO FUTUW001-COD-ERRO       ");
                //this.textoRetorno.add("                                            OF DFHCOMMAREA             ");
                //this.textoRetorno.add("              MOVE '2222-ACESSAR-FUTUB010'  TO FUTU-S-IDEN-PARAGRAFO ");
                //Vthis.textoRetorno.add("              PERFORM 9100-ERRO-DB2                                    ");
                //this.textoRetorno.add("           END-IF.                                                      ");
                //this.textoRetorno.add("           ");
                //this.textoRetorno.add("           IF (SQLCODE                 EQUAL +100) ");                     
                //this.textoRetorno.add("              INITIALIZE FUTUWCCC-BLOCO-SAIDA    ");                      
                //this.textoRetorno.add("              GO                      TO 2222-99-FIM");                   
                //this.textoRetorno.add("           ELSE                                         ");                
                //this.textoRetorno.add("           END-IF.                                      ");                
               
                break;
            }
            case 3: {
                this.textoRetorno.add("           .                                                            ");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2000-99-FIM                     EXIT.                            ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                break;
            }
            case 5: {
                
                this.textoRetorno.add("      *");
            	
        	this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       77  FILLER                      PIC X(050)      VALUE            ");
                this.textoRetorno.add("           '* AREA PARA DEFINICAO DE CURSOR*'.                       ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                break;
            }
            case 6: {
            	 this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       1900-FAZ-OPEN-CURSOR             SECTION");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                
                this.textoRetorno.add("      *");
                this.textoRetorno.add("           EXEC SQL     ");                            
                this.textoRetorno.add("                OPEN CSR01-CURSOR");
                this.textoRetorno.add("           END-EXEC.");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("           IF (SQLCODE                 NOT EQUAL ZEROS AND +100) OR ");     
                this.textoRetorno.add("              (SQLWARN0                EQUAL 'W')                       ");
                this.textoRetorno.add("              SET DB2-SELECT                TO TRUE                     ");
                this.textoRetorno.add("              MOVE '0120'                   TO FUTUW001-COD-ERRO        ");
                this.textoRetorno.add("                                            OF DFHCOMMAREA              ");
                this.textoRetorno.add("              MOVE '1900-FAZ-OPEN -CURSOR'         TO FUTU-S-IDEN-PARAGRAFO    ");
                this.textoRetorno.add("              PERFORM 9100-ERRO-DB2                                     ");
                this.textoRetorno.add("           END-IF.                                                      ");
                this.textoRetorno.add("      *");
                   
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       1900-99-FIM.                     EXIT. ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2000-FAZ FECTH             SECTION");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                
                break;
            }
            case 7: {
            	this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2200-TRATAR-NULIDADE         SECTION");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                break;
            }

            case 8: {
            	 this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2200-99-FIM.                 EXIT.");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                break;
            }

            case 9: {
            	 this.textoRetorno.add("      *");
            	this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2100-FAZ-CLOSE-CURSOR             SECTION");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                
                this.textoRetorno.add("      *");
                this.textoRetorno.add("           EXEC SQL  ");                              
                this.textoRetorno.add("                CLOSE CSR01-CURSOR");
                this.textoRetorno.add("           END-EXEC.");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("           IF (SQLCODE                 NOT EQUAL ZEROS AND +100) OR ");     
                this.textoRetorno.add("              (SQLWARN0                EQUAL 'W')                       ");
                this.textoRetorno.add("              SET DB2-SELECT                TO TRUE                    ");
                this.textoRetorno.add("              MOVE '0120'                   TO FUTUW001-COD-ERRO       ");
                this.textoRetorno.add("                                            OF DFHCOMMAREA             ");
                this.textoRetorno.add("              MOVE '2100-FAZ-CLOSE-CURSOR'  TO FUTU-S-IDEN-PARAGRAFO ");
                this.textoRetorno.add("              PERFORM 9100-ERRO-DB2                                    ");
                this.textoRetorno.add("           END-IF.                                                      ");
                this.textoRetorno.add("      *");
                
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       2100-99-FIM.                     EXIT. ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                break;
            }
            case 10: {
            	this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("       IDENTIFICATION DIVISION.");
                this.textoRetorno.add("      *================================================================*");
                
                this.textoRetorno.add("      *");
                this.textoRetorno.add("           PROGRAM-ID.    PGMTESTE.    ");                              
                this.textoRetorno.add("           AUTHOR.        FUTURE SCHOOL.");
                this.textoRetorno.add("      *");
            
                this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("       ENVIRONMENT                      DIVISION.");
                this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       CONFIGURATION                    SECTION.");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("       SPECIAL-NAMES.");
                this.textoRetorno.add("           DECIMAL-POINT IS COMMA.");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("       DATA DIVISION.");
                this.textoRetorno.add("      *================================================================*");
                this.textoRetorno.add("      *");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       WORKING-STORAGE                  SECTION.");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("                 COPY "   + this.nomeLabel + ".");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       77  FILLER                      PIC X(050)      VALUE            ");
                this.textoRetorno.add("           '* AREA PARA DEFINICAO DE VAVIAVEIS*'.                       ");
                this.textoRetorno.add("      *----------------------------------------------------------------*");
                this.textoRetorno.add("       77  CH-FIM                      PIC X(001)      VALUE 'N'.       ");
                this.textoRetorno.add("       77  FUTUW001-COD-ERRO           PIC 9(002)      VALUE ZERO.      ");
                this.textoRetorno.add("       77  FUT-S-IDEN-PARAGRAFO        PIC X(025)      VALUE SPACES.    ");
                this.textoRetorno.add("      *");
           
                break;
            }
            case 11: {
               this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       9100-ERRO-DB2                     SECTION.                 EXIT.");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
               this.textoRetorno.add("              DISPOLAY 'ERRO NOM PROGRAMA PGMTESTE'       ");
               this.textoRetorno.add("              STOP RUN.      ");
                
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       9100-99-FIM.                      EXIT.");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
                
               this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       9999-FINALIZA                     SECTION.                 EXIT.");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("              DISPOLAY 'PROGRAMA PGMTESTE ENERRADO'       ");
               this.textoRetorno.add("              STOP RUN.      ");
               
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       9999-99-FIM.                      EXIT.");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               break;
           }
            case 12: {
           	   this.textoRetorno.add("      *");
               this.textoRetorno.add("      *================================================================*");
               this.textoRetorno.add("       PROCEDURE DIVISION.                        ");
               this.textoRetorno.add("      *================================================================*");
               this.textoRetorno.add("      *");
                  
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0000-INICIO                      SECTION.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
               this.textoRetorno.add("            PERFORM  0100-PROCEDIMENTOS-INICIAIS."); 
               this.textoRetorno.add("            PERFORM  0200-PROCESSA.");
               this.textoRetorno.add("            PERFORM  9999-FINALIZA.");

               this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0000-99-FIM.                     EXIT.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0100-PROCEDIMENTOS-INICIAIS     SECTION.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
               
               this.textoRetorno.add("            INITIALIZE  AREAS-AUXILIARES.");
               this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0100-99-FIM.                     EXIT.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
              
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0200-PROCESSA                   SECTION.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
               
               this.textoRetorno.add("            PERFORM  0300-ACESSA-TABELA.");
                this.textoRetorno.add("      *");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0200-99-FIM.                     EXIT.                        ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("      *");
              
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("       0300-ACESSA-TABELA              SECTION.                         ");
               this.textoRetorno.add("      *----------------------------------------------------------------*");
               this.textoRetorno.add("");
               break;
           }
        }
    }
}