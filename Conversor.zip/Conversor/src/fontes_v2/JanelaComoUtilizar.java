
package fontes_v2;

import java.io.IOException;
import java.util.Scanner;
import java.io.File;
import javax.swing.event.ListSelectionListener;
import javax.swing.JList;
import java.awt.Font;
import java.awt.Component;
import java.awt.LayoutManager;
import java.awt.Container;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import java.awt.EventQueue;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import javax.swing.JFrame;

public class JanelaComoUtilizar extends JFrame {
    private JPanel contentPane;
    private JTextArea textField;
    private JScrollPane scrollPane_1;
    
    public static void main(final String[] args) {
         EventQueue.invokeLater((Runnable)new JanelaComoUtilizar$1());

    }
    
    public JanelaComoUtilizar() {
        super();
        this.setTitle("Ajuda");
        this.setDefaultCloseOperation(1);
        this.setBounds(100, 100, 600, 400);
        (this.contentPane = new JPanel()).setBorder(new EmptyBorder(5, 5, 5, 5));
        this.setContentPane(this.contentPane);
        this.contentPane.setLayout(null);
        final JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(184, 11, 390, 340);
        this.contentPane.add(scrollPane);
        scrollPane.setViewportView(this.textField = new JTextArea());
        this.textField.setColumns(10);
        this.textField.setFont(new Font("Arial", 0, 12));
        this.textField.setEditable(false);
        this.textField.setText("Selecione o tema da d�vida");
        (this.scrollPane_1 = new JScrollPane()).setBounds(10, 11, 164, 340);
        this.contentPane.add(this.scrollPane_1);
        final String[] opcoes = { "- Para que serve", "- Como utilizar", "- Como comunicar falhas" };
        JList list = new JList (opcoes);
        // JList <String> list = new JList <String> (opcoes);
        list.addListSelectionListener((ListSelectionListener)new JanelaComoUtilizar$2(this, list));
        this.scrollPane_1.setViewportView(list);
    }
    
    public String trataTexto(final String nomeArquivo) {
        final File arq = new File(nomeArquivo);
        String textoTratado = "";
        try {
            final Scanner scan = new Scanner(arq);
            while (scan.hasNextLine()) {
                textoTratado = String.valueOf(textoTratado) + scan.nextLine() + "\n";
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return textoTratado;
    }
    
    static /* synthetic */ JTextArea access$0(final JanelaComoUtilizar janelaComoUtilizar) {
        return janelaComoUtilizar.textField;
    }
}