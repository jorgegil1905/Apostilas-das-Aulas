
// Decompiled using: fernflower
// Took: 9ms

package fontes_v2;

class JanelaComoUtilizar$1 implements Runnable {
    JanelaComoUtilizar$1() {
        super();
    }
    
    public void run() {
        try {
            final JanelaComoUtilizar frame = new JanelaComoUtilizar();
            frame.setVisible(true);
        }
        catch (Exception e) {
             e.printStackTrace();
        }
    }
}