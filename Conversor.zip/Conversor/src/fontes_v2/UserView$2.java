// Fechar
package fontes_v2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class UserView$2 implements ActionListener {
    final /* synthetic */ UserView this$0;
    
    UserView$2(final UserView this$0) {
         super();
        this.this$0 = this$0;
       
    }
    
    public void actionPerformed(final ActionEvent arg0) {
    	int res = 0;
        System.exit(1);
    }
}