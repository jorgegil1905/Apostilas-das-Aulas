
package fontes_v2;

import javax.swing.UIManager;

class JanelaSobre$1 implements Runnable {
    JanelaSobre$1() {
        super();
    }
    
    public void run() {
        try {
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            final JanelaSobre frame = new JanelaSobre();
            frame.setVisible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
} 